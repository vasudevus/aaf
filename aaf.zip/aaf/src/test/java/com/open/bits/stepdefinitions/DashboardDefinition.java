package com.open.bits.stepdefinitions;

import com.open.bits.assertions.Assertions;
import com.open.bits.config.Config;
import com.open.bits.pages.Dashboard;
import com.open.bits.pages.Login;
import com.open.bits.security.Security;
import com.open.bits.threadVariables.VariableManager;
import com.open.bits.webDriverFactory.ManagerDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.net.MalformedURLException;

public class DashboardDefinition {


	Assertions assertions = new Assertions();

	Dashboard dashboard = new Dashboard();
	@Then("User should be able to view the {string} page" )
	public void User_should_be_able_to_view_the_page(String pageName) throws Exception {
		String dashboardTitle= dashboard.getDashBoardTitle();
		assertions.assert2ValuesFromUI("Dashboard Title verification",pageName,dashboardTitle);


	}


}