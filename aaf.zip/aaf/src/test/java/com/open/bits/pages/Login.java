package com.open.bits.pages;

import com.open.bits.logger.LoggerClass;
import com.open.bits.config.Config;
import com.open.bits.threadVariables.VariableManager;
import com.open.bits.uiUtils.UIUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import static java.lang.System.*;

public class Login  extends UIUtils {

	org.apache.log4j.Logger log = LoggerClass.getThreadLogger("Thread" + Thread.currentThread().getName(), VariableManager.getInstance().getVariables().getVar("testCaseID").toString());

	WebDriver driver = null;
	String pageName = "Login Page";
	@FindBy(how = How.ID, using = "username")
	WebElement UserName;
	@FindBy(how = How.ID, using = "password")
	WebElement Password;
	@FindBy(how = How.ID, using = "loginNewBtn")
	WebElement Login;
	@FindBy(how = How.ID, using = "//logout-button")
	WebElement LogOut;




	@FindBy(how = How.XPATH, using = "//*[@class='commonBtn SignIn']")
	WebElement SiginIn;

	@FindBy(how = How.XPATH, using = "//*[@class='signup-privacy-a']")
	WebElement CreateAccount;

	@FindBy(how = How.ID, using = "businessUser")
	WebElement BusinessUser;

	@FindBy(how = How.ID, using = "nextButton")

	WebElement NextButton;
	@FindBy(how = How.XPATH, using = "//*[@class='signup-template']")
	WebElement welcomeAboardTitle;



	public Login() {
		this.driver = (WebDriver) VariableManager.getInstance().getVariables().getVar("driver");
		PageFactory.initElements(this.driver, this);
	}

	public void lauchApplication() throws InterruptedException {
		String Env = getProperty("Environment");
		if (Env == null) {
			Env = Config.properties.getProperty("Environment");
		}
		String url = Config.properties.getProperty(Env);
		driver.get(url);
		Thread.sleep(1000);
		log.info("Thread ID:'" + Thread.currentThread().getId() + "' 'PASS' opened application '" + url + "'");

	}

	public void login(String userName, String password) throws Exception {

		type(UserName, userName, "UserName", this.pageName);
		type(Password, password, "Password", this.pageName);
		clickElement(Login, "Login", this.pageName);
	}

	public void ClickSignIn() throws Exception {

		clickElement(SiginIn, "SiginIn", this.pageName);
	}

	public void CreateAccount() throws Exception {

		clickElement(CreateAccount, "CreateAccount", this.pageName);
	}

	public void ClickBusinessUser() throws Exception {

		clickElement(BusinessUser, "BusinessUser", this.pageName);
	}

	public void ClickNextButton() throws Exception {
		Thread.sleep(2000);
		clickElement(NextButton, "NextButton", this.pageName);
		System.out.println("After Clicking Next Button");
		String pageSource = driver.getPageSource();
		System.out.println(pageSource);

	}
	public String getWelcomeAboardTitle() throws Exception {
		Thread.sleep(5000);
		String pageSource = driver.getPageSource();
		System.out.println(pageSource);
		return welcomeAboardTitle.getText();

	}

}
