package com.open.bits.stepdefinitions;

import com.open.bits.config.Config;
import com.open.bits.pages.Login;
import com.open.bits.security.Security;
import com.open.bits.threadVariables.VariableManager;
import com.open.bits.webDriverFactory.ManagerDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.net.MalformedURLException;

public class LoginDefinition {
	
	public Login login;
	WebDriver driver;

	@Given("Open Browser")
	public void Open_Browser() throws MalformedURLException {
		String browser = System.getProperty("Browser");
		if (browser == null) {
			browser = Config.properties.getProperty("Browser");
		}
		String ExecutionMode = System.getProperty("ExecutionMode");
		if (ExecutionMode == null) {
			ExecutionMode = Config.properties.getProperty("ExecutionMode");
		}
		String RemoteURL = System.getProperty("RemoteURL");
		if (RemoteURL == null) {
			RemoteURL = Config.properties.getProperty("RemoteURL");
		}
		String testCaseID = VariableManager.getInstance().getVariables().getVar("testCaseID").toString();
		String testName = Config.properties.getProperty("BuildName") + "- Test Case Id : '" + testCaseID + "'";
		String buildId = Config.properties.getProperty("BuildId");
		driver = ManagerDriver.getInstance().getDriver(ExecutionMode, browser, RemoteURL, testName, buildId);
		VariableManager.getInstance().getVariables().setVar("driver", driver);
		this.login = new Login();
	}

	@Given("User is able Launch the Melp application")
	public void user_is_able_Launch_the_Melp_application () throws InterruptedException {
		login.lauchApplication();
	}
	
	@When("User enters the Username and Password and Click LogIn button")
	public void user_enters_the_and() throws Exception {
		String Username = Config.properties.getProperty("Username");
		String Password = Config.properties.getProperty("Password");
		Security security = new Security();
		String decryptedpassword =security.decryptPassword(Password);
		login.login(Username, decryptedpassword);
	}

//	@Then("LogOut application")
//	public void logout_application() throws Exception {
//		login.LogOut();
//	}

//	@When("User enters the user name and password and Click LogIn button")
//	public void user_enters_and_password() throws Exception {
//		MobileLogin mobilrLogin = new MobileLogin();
//		mobilrLogin.login();
//	}

	@Then("User should be able to view the dashboard")
	public void userShouldBeAbleToViewTheDashboard() throws Exception {

	}

	@Given("I am on the Home Page and Click the Sigin button")
	public void iAmOnTheHomePageAndClickTheSiginButton() throws Exception {
		login.ClickSignIn();

	}

	@When("I navigate to the Login page and Click on Create Account")
	public void iNavigateToTheLoginPageAndClickOnCreateAccount() throws Exception {
		login.CreateAccount();
	}


	@And("I click on {string}")
	public void iClickOn(String arg0) throws Exception {
		login.ClickBusinessUser();

	}

	@And("I click on {string} button to proceed")
	public void iClickOnButtonToProceed(String arg0) throws Exception {
		login.ClickNextButton();

	}


	@And("Click on CreateAccount Button")
	public void clickOnCreateAccountButton() {
	}


//    @Then(value = "the {Welcome Aboard} page should be displayed")
//    public void thePageShouldBeDisplayed(Object o) {
//        thePageShouldBeDisplayed(null);
    }


