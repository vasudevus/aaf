package com.open.bits.pages;

import com.open.bits.logger.LoggerClass;
import com.open.bits.threadVariables.VariableManager;
import com.open.bits.uiUtils.UIUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Welcome extends UIUtils {

	org.apache.log4j.Logger log = LoggerClass.getThreadLogger("Thread" + Thread.currentThread().getName(), VariableManager.getInstance().getVariables().getVar("testCaseID").toString());

	WebDriver driver = null;
	String pageName = "Welcome Page";
	//@FindBy(how = How.XPATH, using = "//*[@id='header-module']")
	@FindBy(how = How.XPATH, using = "//*[@id=\"thankyou-template\"]/div/div[3]/div/span]")
	WebElement dashboardTitle;


	public Welcome(){
		this.driver = (WebDriver) VariableManager.getInstance().getVariables().getVar("driver");
		PageFactory.initElements(this.driver, this);
	}

	public String getDashBoardTitle() throws Exception {
		Thread.sleep(2000);
		return dashboardTitle.getText();


	}

	public void LogOut() throws Exception {

		//clickElement(LogOut, "LogOut", this.pageName);
	}

}